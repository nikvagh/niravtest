import 'dart:async';
import 'dart:convert';
import 'dart:io';
import "dart:math";
import 'package:camera/camera.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterapp/model/game_model.dart';
import 'package:flutterapp/util/app.dart';
import 'package:flutterapp/util/shar_pref.dart';
import 'package:flutterapp/util/util.dart';
import 'package:path_provider/path_provider.dart';

// ignore: must_be_immutable
class Timers extends StatefulWidget {
  String strPlayer = "";
  String strDifficulty = "";
  int totalGame = 0;
  Function(bool) isGameRunningCallback;

  Timers(this.totalGame, this.strPlayer, this.strDifficulty,
      this.isGameRunningCallback);

  @override
  _TimersState createState() => _TimersState();
}

List<CameraDescription> cameras = [];

void logError(String code, String message) =>
    print('Error: $code\nError Message: $message');

class _TimersState extends State<Timers> with WidgetsBindingObserver {
  int currentReverse = 15;
  int max = 15;
  int current = 0;
  String strDesc = "Click Cards To Start";
  String currentCard = "";
  List<String> currentCards = new List<String>();
  int currentCardIndex = 0;
  bool isGameRunning = false;
  String imagePath;
  List<String> imagePaths = new List<String>();
  int addCurrent = 0;

  GameModel gameModel = new GameModel();
  User user = new User();
  PlayerGame playerGame = new PlayerGame();

  Timer t;
  List<String> carDarr = new List<String>();
  final _random = new Random();
  int darrLimit = 3;
  CameraController controller;
  List<CameraDescription> cameras = [];

  @override
  void initState() {
    super.initState();
    try {
      WidgetsFlutterBinding.ensureInitialized();
      availableCameras().then((camera) {
        cameras = camera;
        setState(() {});
      });
    } on CameraException catch (e) {
      logError(e.code, e.description);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // App state changed before we got the chance to initialize.
    if (controller == null || !controller.value.isInitialized) {
      return;
    }
    if (state == AppLifecycleState.inactive) {
      controller?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      if (controller != null) {
        onNewCameraSelected(controller.description);
      }
    }
  }

  //open camera
  void onNewCameraSelected(CameraDescription cameraDescription) async {
    //onNewCameraSelected -> 0 90 CameraLensDirection.back
    print("onNewCameraSelected -> " +
        cameraDescription.name.toString() +
        " " +
        cameraDescription.sensorOrientation.toString() +
        " " +
        cameraDescription.lensDirection.toString());

    if (controller != null) {
      await controller.dispose();
    }
    controller = CameraController(
      cameraDescription,
      ResolutionPreset.medium,
    );

    // If the controller is updated then update the UI.
    controller.addListener(() {
      if (mounted) setState(() {});
      if (controller.value.hasError) {
        print("Camera error ${controller.value.errorDescription}");
      }
    });

    try {
      await controller.initialize().then((temp) {});
    } on CameraException catch (e) {
      _showCameraException(e);
    }

    if (mounted) {
      setState(() {});
    }
  }

  void _showCameraException(CameraException e) {
    logError(e.code, e.description);
  }

  //came view
  Widget _cameraPreviewWidget() {
    if (controller == null || !controller.value.isInitialized) {
      return const Text(
        'Click a Card',
        style: TextStyle(
          color: Colors.white,
          fontSize: 24.0,
          fontWeight: FontWeight.w900,
        ),
      );
    } else {
      return AspectRatio(
        aspectRatio: controller.value.aspectRatio,
        child: CameraPreview(controller),
      );
    }
  }

  void onTakePictureButtonPressed() {
    if (controller != null &&
        controller.value.isInitialized &&
        !controller.value.isRecordingVideo) {
      takePicture().then((String filePath) {
        if (mounted) {
          setState(() {
            imagePath = filePath;
          });
          if (filePath != null) showInSnackBar('Picture saved to $filePath');
        }
      });
    }
  }

  String timestamp() => DateTime.now().millisecondsSinceEpoch.toString();

  void showInSnackBar(String message) {
    print("showInSnackBar -> " + message);
  }

  Future<String> takePicture() async {
    if (!controller.value.isInitialized) {
      showInSnackBar('Error: select a camera first.');
      return null;
    }
    final Directory extDir = await getApplicationDocumentsDirectory();
    final String dirPath = '${extDir.path}/Pictures/flutter_test';
    await Directory(dirPath).create(recursive: true);
    final String filePath = '$dirPath/${timestamp()}.jpg';

    if (controller.value.isTakingPicture) {
      // A capture is already pending, do nothing.
      return null;
    }

    try {
      await controller.takePicture(filePath);
    } on CameraException catch (e) {
      _showCameraException(e);
      return null;
    }
    return filePath;
  }

  @override
  Widget build(BuildContext context) {
    /*if (!cameras.isEmpty) {
      if (controller == null || !controller.value.isRecordingVideo) {
        onNewCameraSelected(new CameraDescription(
            name: "0",
            sensorOrientation: 90,
            lensDirection: CameraLensDirection.back));
      }
    }*/

    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.all(0),
      child: Center(
        child: ListView(children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(left: 20, top: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Players",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.left,
                            ),
                            Text(
                              "Difficulty",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.left,
                            )
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              " : ",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.left,
                            ),
                            Text(
                              " : ",
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.left,
                            )
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "${widget.strPlayer}",
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black),
                              textAlign: TextAlign.left,
                            ),
                            Text(
                              "${widget.strDifficulty}",
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black),
                              textAlign: TextAlign.left,
                            )
                          ],
                        )
                      ],
                    ),
                  ],
                ),
              ),
              Flexible(
                child: Container(
                  color: Colors.transparent,
                ),
              ),
              Container(
                height: 0,
                width: 0,
                alignment: Alignment.center,
                color: Colors.black,
                padding: const EdgeInsets.all(1.0),
                child: (isGameRunning)
                    ? Center(
                        child: _cameraPreviewWidget(),
                      )
                    : Container(),
              )
            ],
          ),
          Text(
            (isGameRunning) ? "$currentReverse" : "${strCurrentReverse()}",
            style: TextStyle(
              fontSize: 60,
              color: Colors.red,
              fontFamily: 'roboto'
            ),
            textAlign: TextAlign.center,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              RaisedButton(
                onPressed: add5Timer,
                child: Text("Add 5"),
              ),
              RaisedButton(
                onPressed: add10Timer,
                child: Text("Add 10"),
              ),
              RaisedButton(
                onPressed: pass,
                child: Text("Pass"),
              ),
            ],
          ),
          SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            Flexible(
              child: Container(
                height: 250.0,
                width: MediaQuery.of(context).size.width,
                child: Card(
                    color: Colors.black26,
                    child: InkWell(
                      onTap: () {
                        if (!isGameRunning) {
                          gameStart();
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'Pile of Cards',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )),
              ),
              flex: 1,
            ),
            Flexible(
              child: Container(
                height: 250.0,
                width: MediaQuery.of(context).size.width,
                child: Card(
                  child: InkWell(
                    onTap: carDarrDone,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            currentCard,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              flex: 1,
            ),
          ]),
          Text(
            strDesc,
            style: TextStyle(fontSize: 30),
            textAlign: TextAlign.center,
          ),
          Text(
            '$current',
            style: TextStyle(fontSize: 30),
            textAlign: TextAlign.center,
          )
        ]),
      ),
    );
  }

  //current reverse string
  int strCurrentReverse() {
    switch (widget.strDifficulty) {
      case "Medium":
        return 15;
        break;
      case "Hard":
        return 10;
        break;
      case "Easy":
      default:
        return 20;
        break;
    }
  }

  //start game
  void gameStart() {
    switch (widget.strDifficulty) {
      case "Medium":
        carDarr.clear();
        carDarr.addAll(App.carDarrMed);
        break;
      case "Hard":
        carDarr.clear();
        carDarr.addAll(App.carDarrHard);
        break;
      case "Easy":
      default:
        carDarr.clear();
        carDarr.addAll(App.carDarrEasy);
        break;
    }

    imagePaths.clear();
    currentReverse = strCurrentReverse();
    max = strCurrentReverse();
    darrLimit = int.parse(widget.strPlayer) - 1;

    currentCards.clear();

    for (int i = 0; i < darrLimit + 1; i++) {
      int k = _random.nextInt(carDarr.length);
      print("carDarrDone -> " + k.toString());
      currentCards.add(carDarr[k]);
      carDarr.removeAt(k);
    }

    if (cameras.isNotEmpty) {
      if (controller == null || !controller.value.isRecordingVideo) {
        onNewCameraSelected(new CameraDescription(
            name: "1",
            sensorOrientation: 270,
            lensDirection: CameraLensDirection.front));
      }
    }
    gameModel.startDateTime = DateTime.now();
    t = Timer.periodic(Duration(seconds: 1), (timer) {
      print("Timer.periodic -> " +
          timer.tick.toString() +
          " " +
          currentReverse.toString());
      //timer complated
      if (timer.tick == max + addCurrent || currentReverse == 0) {
        t.cancel();
        gameModel.endDateTime = DateTime.now();
        isGameRunning = false;
        widget.isGameRunningCallback(false);

        currentReverse = max - timer.tick + addCurrent;
        current = timer.tick;
        DateTime currentDateTime = DateTime.now();

        //game
        //3
        playerGame.endDateTime = currentDateTime;
        playerGame.durationInMilisecond = playerGame.endDateTime
            .difference(playerGame.startDateTime)
            .inMilliseconds;
        playerGame.isDone = false;
        playerGame.isDownloaded=false;
        //2
        if (user.playerGame == null) {
          user.playerGame = new List<PlayerGame>();
        }
        user.playerGame.add(playerGame);
        //1
        if (gameModel.user == null) {
          gameModel.user = new List<User>();
        }
        gameModel.isWin = false;
        gameModel.user.add(user);
        gameModel.takenSecond = current;
        gameModel.totalSecond = max;
        print("game_model -> " + jsonEncode(gameModel.toJson()).toString());
        print("showDia -> " + imagePaths.length.toString());

        showDia(context, false, max.toString(), imagePaths);

        resetVariable();
      }
      //first second
      else if (timer.tick == 1) {
        imagePath = "";
        onTakePictureButtonPressed();
        isGameRunning = true;
        widget.isGameRunningCallback(true);

        currentReverse = max - timer.tick + addCurrent;
        current = timer.tick;

        currentCard = currentCards[currentCardIndex];

        DateTime currentDateTime = DateTime.now();
        //game
        //3
        playerGame.objectName = currentCard;
        playerGame.startDateTime = currentDateTime;
        //2
        user.id = 1;
        user.totalGame = darrLimit;
        user.totalSuccess = 0;
        user.totalPassed = 0;
        //1
        gameModel.name = (widget.totalGame + 1).toString();

        setState(() {});
      }
      //else
      else {
        currentReverse = max - timer.tick + addCurrent;
        current = timer.tick;
        setState(() {});
      }
    });
  }

  //add 5 second in timer
  void add5Timer() {
    if (isGameRunning) {
      max = max + 5;
      currentReverse = currentReverse + 5;
      setState(() {});
    }
  }

  //add 10 second in timer
  void add10Timer() {
    if (isGameRunning) {
      max = max + 10;
      currentReverse = currentReverse + 10;
      setState(() {});
    }
  }

  //pass current dare
  void pass() {
    currentCardIndex++;
    if (currentCardIndex > currentCards.length - 1) {
      currentCardIndex = 0;
    }
    currentCard = currentCards[currentCardIndex];

    user.totalPassed = user.totalPassed + 1;
    setState(() {});
  }

  //complete current date
  void carDarrDone() {
    DateTime currentDateTime = DateTime.now();
    print("carDarrDone -> " + currentCards.length.toString());
    currentCards.removeAt(currentCardIndex);
    print("carDarrDone -> " + currentCards.length.toString());
    if (currentCardIndex > currentCards.length - 1) {
      currentCardIndex = 0;
    }
    if (currentCards.length != 0) {
      currentCard = currentCards[currentCardIndex];
    }

    //game
    //3
    playerGame.endDateTime = currentDateTime;
    playerGame.durationInMilisecond = playerGame.endDateTime
        .difference(playerGame.startDateTime)
        .inMilliseconds;
    playerGame.imagePath = imagePath;
    imagePaths.add(imagePath);
    imagePath = "";
    onTakePictureButtonPressed();
    playerGame.isDone = true;
    playerGame.isDownloaded=false;
    //2
    if (user.playerGame == null) {
      user.playerGame = new List<PlayerGame>();
    }
    user.totalSuccess = user.totalSuccess + 1;
    user.playerGame.add(playerGame);

    if (user.totalSuccess == darrLimit) {
      t.cancel();
      gameModel.endDateTime = DateTime.now();
      //1
      if (gameModel.user == null) {
        gameModel.user = new List<User>();
      }
      gameModel.user.add(user);
      gameModel.isWin = true;
      gameModel.takenSecond = current;
      gameModel.totalSecond = max;
      print("game_model -> " + jsonEncode(gameModel.toJson()).toString());
      print("showDia -> " + imagePaths.length.toString());

      showDia(
          context,
          true,
          (gameModel.endDateTime
                      .difference(gameModel.startDateTime)
                      .inMilliseconds /
                  1000)
              .toStringAsFixed(2),
          imagePaths);
      resetVariable();
    } else {
      //3
      playerGame = new PlayerGame();
      playerGame.objectName = currentCard;
      playerGame.startDateTime = currentDateTime;

      currentReverse = strCurrentReverse();
      max = strCurrentReverse();
      addCurrent = current;
    }
    setState(() {});
  }

  // reset all variables
  Future<void> resetVariable() async {
    await Shared_Preferences.prefSetString(
        Shared_Preferences.keyGame + (widget.totalGame + 1).toString(),
        jsonEncode(gameModel.toJson()).toString());
    await Shared_Preferences.prefSetInt(
        Shared_Preferences.keyGameCounter, widget.totalGame + 1);
    widget.totalGame++;
    currentReverse = 15;
    max = 15;
    current = 0;
    strDesc = "Click Cards To Start";
    currentCard = "";
    currentCardIndex = 0;
    addCurrent = 0;

    isGameRunning = false;
    widget.isGameRunningCallback(false);

    gameModel = new GameModel();
    user = new User();
    playerGame = new PlayerGame();
    setState(() {});
  }
}
