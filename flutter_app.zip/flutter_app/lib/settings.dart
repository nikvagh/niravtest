import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterapp/util/shar_pref.dart';

// ignore: must_be_immutable
class Settings extends StatefulWidget {
  String selectedPlayer = "3";
  String selectedDifficulty = "Hard";

  Settings(this.selectedPlayer, this.selectedDifficulty);

  @override
  _SettingsState createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  String selectedPlayer = "3";
  String selectedDifficulty = "Hard";
  List<String> listPlayer = ['2', '3', '4', '5', '6', '7', '8'];
  List<String> listDifficulty = ['Easy', 'Medium', 'Hard'];

  @override
  void initState() {
    super.initState();
    selectedPlayer = widget.selectedPlayer;
    selectedDifficulty = widget.selectedDifficulty;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: onBackPressed,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Settings'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Players: ",
                      style: TextStyle(fontSize: 20, color: Colors.blue)),
                  new DropdownButton<String>(
                    value: selectedPlayer,
                    hint: Text("Number of Players"),
                    items: listPlayer.map((String value) {
                      return new DropdownMenuItem<String>(
                        value: value,
                        child: Row(
                          children: <Widget>[
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              value,
                              style: TextStyle(color: Colors.black),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (String value) {
                      setState(() {
                        selectedPlayer = value;
                      });
                    },
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Difficulty: ",
                      style: TextStyle(fontSize: 20, color: Colors.blue)),
                  new DropdownButton<String>(
                    value: selectedDifficulty,
                    hint: Text("Choose Difficulty"),
                    items: listDifficulty.map((String value) {
                      return new DropdownMenuItem<String>(
                        value: value,
                        child: Row(
                          children: <Widget>[
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              value,
                              style: TextStyle(color: Colors.black),
                            ),
                          ],
                        ),
                        //child: new Text(value),
                      );
                    }).toList(),
                    onChanged: (String value) {
                      setState(() {
                        selectedDifficulty = value;
                      });
                    },
                  ),
                ],
              ),
              SizedBox(
                height: 50,
              ),
              new RaisedButton(
                onPressed: onBack,
                color: Colors.blue,
                child: new Text("Let's Play!",
                    style: TextStyle(fontSize: 20, color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ignore: missing_return
  Future<bool> onBackPressed() {
    onBack();
  }

  onBack() {
    Shared_Preferences.prefSetString(
            Shared_Preferences.keySettingPlayers, selectedPlayer)
        .then((temp) {
      Shared_Preferences.prefSetString(
              Shared_Preferences.keySettingDifficulty, selectedDifficulty)
          .then((temp1) {
        Navigator.of(context).pop();
      });
    });
  }
}
