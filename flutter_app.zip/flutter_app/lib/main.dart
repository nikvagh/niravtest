import 'package:flutter/material.dart';
import 'package:flutterapp/scores.dart';
import 'package:flutterapp/settings.dart';
import 'package:flutterapp/timers.dart';
import 'package:flutterapp/util/navigate_effect.dart';
import 'package:flutterapp/util/shar_pref.dart';

Future<void> main() async {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue, fontFamily: 'gothic'
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
      routes: <String, WidgetBuilder>{},
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String selectedPlayer = "3";
  String selectedDifficulty = "Hard";
  int totalGame = 0;
  bool isGameRunning = false;

  @override
  void initState() {
    super.initState();
    clearValue();
  }

  void clearValue() {
    Shared_Preferences.clearAllPref().then((temp) {
      setState(() {});
    });
  }

  void getValue() {
    Shared_Preferences.prefGetInt(Shared_Preferences.keyGameCounter, 0)
        .then((gameCounter) {
      totalGame = gameCounter;
      Shared_Preferences.prefGetString(
              Shared_Preferences.keySettingPlayers, "3")
          .then((player) {
        selectedPlayer = player;
        Shared_Preferences.prefGetString(
                Shared_Preferences.keySettingDifficulty, "Hard")
            .then((difficulty) {
          selectedDifficulty = difficulty;
          setState(() {});
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Charade Parade',),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.score),
            onPressed: () {
              if (!isGameRunning) {
                Navigator.push(context, NavigatePageRoute(context, Scores()))
                    .then((temp) {
                  getValue();
                });
              }
            },
          ),
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () {
              if (!isGameRunning) {
                Navigator.push(
                        context,
                        NavigatePageRoute(context,
                            Settings(selectedPlayer, selectedDifficulty)))
                    .then((temp) {
                  getValue();
                });
              }
            },
          ),
        ],
      ),
      body: Center(
        child: Timers(totalGame, selectedPlayer, selectedDifficulty, callback),
      ),
    );
  }

  callback(bool) {
    isGameRunning = bool;
  }
}
