
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutterapp/util/app.dart';


exitDialogue(BuildContext context) {
  showDialog( barrierDismissible: false,
    context: context,
    builder: (BuildContext context) => new CupertinoAlertDialog(
      title: new Text(App.app_name),
      content: new Text("Are you sure you want to exit?"),
      actions: [
        CupertinoDialogAction(
          isDefaultAction: true,
          child: Text("Yes"),
          onPressed: () {
            SystemNavigator.pop(animated: true);
          },
        ),
        CupertinoDialogAction(
          child: Text("No"),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ],
    ),
  );
}

confirmBack(BuildContext context) {
  FocusScope.of(context).requestFocus(FocusNode());
  showDialog( barrierDismissible: false,
    context: context,
    builder: (BuildContext c) {
      // return object of type Dialog
      return AlertDialog(
        title: new Text(
          "Alert",
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        content: new Text("Going Back without changes?",
            style: TextStyle(fontWeight: FontWeight.w500)),
        actions: <Widget>[
          // usually buttons at the bottom of the dialog
          new FlatButton(
            child: new Text(
              "No",
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            onPressed: () {
              Navigator.of(c).pop();
            },
          ),
          new FlatButton(
            child: new Text(
              "Yes",
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            onPressed: () {
              Navigator.of(c).pop();
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}

//
void commonMessage(BuildContext context, String message) {

  showDialog( barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      // return object of type Dialog
      return AlertDialog(
        title: new Text(
          "Message",
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        content:
            new Text(message, style: TextStyle(fontWeight: FontWeight.w500)),
        actions: <Widget>[
          // usually buttons at the bottom of the dialog
          new FlatButton(
            child: new Text(
              "Ok",
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}
