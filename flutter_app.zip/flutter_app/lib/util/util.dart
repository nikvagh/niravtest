import 'dart:io';
import 'dart:typed_data';

import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutterapp/util/app.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_view/photo_view.dart';

Connectivity connectivity = Connectivity();

Future<bool> isConnectNetwork(BuildContext context) async {
  var connectivityResult = await connectivity.checkConnectivity();
  bool isConnect = getConnectionValue(connectivityResult);
  return isConnect;
}

bool getConnectionValue(var connectivityResult) {
  bool status = false;
  switch (connectivityResult) {
    case ConnectivityResult.mobile:
      status = true;
      break;
    case ConnectivityResult.wifi:
      status = true;
      break;
    case ConnectivityResult.none:
      status = false;
      break;
    default:
      status = false;
      break;
  }
  return status;
}

openKeyBoard(BuildContext context, FocusNode focusNode) {
  FocusScope.of(context).requestFocus(focusNode);
}

void onLoading(BuildContext context, {String strMessage}) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(15))),
        content: Container(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                alignment: Alignment.center,
                height: 100,
                padding: EdgeInsets.only(left: 20, right: 20),
                child: CircularProgressIndicator(
                  valueColor: new AlwaysStoppedAnimation<Color>(App.clrBlack),
                ),
                margin: EdgeInsets.only(bottom: 20),
              ),
              (strMessage != null)
                  ? Flexible(
                      child: Text(
                        strMessage,
                        maxLines: 2,
                        style: new TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: App.clrBlack),
                      ),
                      flex: 1,
                    )
                  : Container(),
            ],
          ),
        ),
      );
    },
  );
}

const formatDate = 'dd/MM';

String getDateDifference(DateTime dateTime) {
  if (dateTime == null) return "";

  if (dateTime.day == DateTime.now().day &&
      dateTime.month == DateTime.now().month &&
      dateTime.year == DateTime.now().year) {
    return "Today";
  } else if (dateTime.day == DateTime.now().subtract(Duration(hours: 24)).day &&
      dateTime.month == DateTime.now().subtract(Duration(hours: 24)).month &&
      dateTime.year == DateTime.now().subtract(Duration(hours: 24)).year) {
    return "Yesterday";
  } else {
    return DateTime.now().difference(dateTime).inDays.toString() + "days ago";
  }
}

void showDia(BuildContext context, bool isWin, String strScore,
    List<String> imagePaths) {
  showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10)), //this right here
          child: Container(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  (imagePaths.length == 0)
                      ? Container()
                      : (imagePaths.length == 1)
                          ? Image.file(
                              File(imagePaths[0]),
                              fit: BoxFit.fill,
                              height: 300,
                              width: MediaQuery.of(context).size.width,
                            )
                          : Container(
                              height: (imagePaths.length == 2) ? 150 : 300,
                              child: GridView.builder(
                                itemCount: imagePaths.length,
                                gridDelegate:
                                    new SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 2),
                                itemBuilder: (BuildContext context, int index) {
                                  return Stack(
                                    children: <Widget>[
                                      Container(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        height: 150,
                                        margin: EdgeInsets.all(5),
                                        child: (imagePaths[index] != null &&
                                                imagePaths[index] != "")
                                            ? Image.file(
                                                File(imagePaths[index]),
                                                fit: BoxFit.fill,
                                              )
                                            : Icon(
                                                Icons.image,
                                                size: 30,
                                              ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.all(10),
                                        child: Text(
                                          (index + 1).toString(),
                                          style: TextStyle(color: Colors.white),
                                        ),
                                        padding: EdgeInsets.all(5),
                                        decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: Colors.grey),
                                      )
                                    ],
                                  );
                                },
                              ),
                            ),
                  Text(
                    (isWin) ? "Game Won!" : "Game Lose!",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
                  ),
                  Text(
                    strScore.toString(),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 20,
                        color: (isWin) ? Colors.green : Colors.red),
                  ),
                  SizedBox(
                    width: 320.0,
                    child: RaisedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: Text(
                        "Cancle",
                        style: TextStyle(color: Colors.white),
                      ),
                      color: const Color(0xFF1BC0C5),
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      });
}

void showDiaImage(BuildContext context, String imagePaths) {
  showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
          backgroundColor: Colors.transparent, //this right here
          child: Container(
            color: Colors.transparent,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 300,
                  color: Colors.transparent,
                  child: PhotoView(
                    imageProvider: FileImage(File(imagePaths)),
                  ),
                ),
              ],
            ),
          ),
        );
      });
}

shareImage(String str) async {

  // for share in ios check this https://stackoverflow.com/a/50007287
  try {

    final channel = const MethodChannel('channel:me.albie.share/share');
    channel.invokeMethod('shareFile', str);

  } catch (e) {
    print('Share error: $e');
  }
}