import 'package:flutter/material.dart';

bool isLight = true;

class App {
  static const app_name = "Charade Parade";

  static const root = 'assets/icon/';
  static const img_file = '$root' + 'img_file.png';

  static const Color clrBg = Color(0x00ffF9F9F9);
  static const Color clrBlack = Color(0x00ff000000);
  static const Color clrWhite = Color(0x00ffFFFFFF);
  static const Color clrRed = Color(0x00ffFF0000);
  static const Color clrGreen = Color(0x00ff00FF00);
  static const Color clrBlue = Color(0x00ff0000FF);

  static const List<String> carDarrEasy = [
    'apple',
    'banana',
    'carrot',
    'dog',
    'elephant',
    'fire truck',
    'garbage can'
  ];
  static const List<String> carDarrMed = [
    'helping',
    'ice',
    'jumping',
    'kangaroo',
    'lion',
    'mouse',
    'nuts'
  ];
  static const List<String> carDarrHard = [
    'octopus',
    'princess',
    'queen',
    'rolling',
    'sandwich',
    'turtle',
    'umbrella'
  ];
}
