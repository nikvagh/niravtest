
class GameModel {
  GameModel({
    this.name,
    this.startDateTime,
    this.endDateTime,
    this.isWin,
    this.takenSecond,
    this.totalSecond,
    this.isVisible,
    this.user,
  });

  String name;
  DateTime startDateTime;
  DateTime endDateTime;
  bool isWin;
  int takenSecond;
  int totalSecond;
  dynamic isVisible;
  List<User> user;

  factory GameModel.fromJson(Map<String, dynamic> json) => GameModel(
    name: json["name"],
    startDateTime: DateTime.parse(json["start_date_time"]),
    endDateTime: DateTime.parse(json["end_date_time"]),
    isWin: json["is_win"],
    takenSecond: json["taken_second"],
    totalSecond: json["total_second"],
    isVisible: json["is_visible"],
    user: List<User>.from(json["user"].map((x) => User.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "start_date_time": startDateTime.toIso8601String(),
    "end_date_time": endDateTime.toIso8601String(),
    "is_win": isWin,
    "taken_second": takenSecond,
    "total_second": totalSecond,
    "is_visible": isVisible,
    "user": List<dynamic>.from(user.map((x) => x.toJson())),
  };
}

class User {
  User({
    this.id,
    this.totalSuccess,
    this.totalPassed,
    this.totalGame,
    this.playerGame,
  });

  int id;
  int totalSuccess;
  int totalPassed;
  int totalGame;
  List<PlayerGame> playerGame;

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json["id"],
    totalSuccess: json["total_success"],
    totalPassed: json["total_passed"],
    totalGame: json["total_game"],
    playerGame: List<PlayerGame>.from(json["player_game"].map((x) => PlayerGame.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "total_success": totalSuccess,
    "total_passed": totalPassed,
    "total_game": totalGame,
    "player_game": List<dynamic>.from(playerGame.map((x) => x.toJson())),
  };
}

class PlayerGame {
  PlayerGame({
    this.objectName,
    this.startDateTime,
    this.endDateTime,
    this.durationInMilisecond,
    this.isDone,
    this.isDownloaded,
    this.downloadedPath,
    this.imagePath,
  });

  String objectName;
  DateTime startDateTime;
  DateTime endDateTime;
  int durationInMilisecond;
  bool isDone;
  bool isDownloaded;
  String downloadedPath;
  String imagePath;

  factory PlayerGame.fromJson(Map<String, dynamic> json) => PlayerGame(
    objectName: json["object_name"],
    startDateTime: DateTime.parse(json["start_date_time"]),
    endDateTime: DateTime.parse(json["end_date_time"]),
    durationInMilisecond: json["duration_in_milisecond"],
    isDone: json["is_done"],
    isDownloaded: json["is_downloaded"],
    downloadedPath: json["downloaded_path"],
    imagePath: json["image_path"],
  );

  Map<String, dynamic> toJson() => {
    "object_name": objectName,
    "start_date_time": startDateTime.toIso8601String(),
    "end_date_time": endDateTime.toIso8601String(),
    "duration_in_milisecond": durationInMilisecond,
    "is_done": isDone,
    "is_downloaded": isDownloaded,
    "downloaded_path": downloadedPath,
    "image_path": imagePath,
  };
}
