import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterapp/model/game_model.dart';
import 'package:flutterapp/util/shar_pref.dart';
import 'package:flutterapp/util/util.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_view/photo_view.dart';

class Scores extends StatefulWidget {
  @override
  _ScoresState createState() => _ScoresState();
}

class _ScoresState extends State<Scores> {
  List<GameModel> gameModels = new List<GameModel>();

  @override
  void initState() {
    super.initState();
    getRecords();
  }

  void getRecords() {
    gameModels.clear();
    Shared_Preferences.prefGetInt(Shared_Preferences.keyGameCounter, 0)
        .then((count) async {
      for (int i = 1; i <= count; i++) {
        gameModels.add(GameModel.fromJson(jsonDecode(
            await Shared_Preferences.prefGetString(
                Shared_Preferences.keyGame + i.toString(), ""))));
        if (i == count) {
          setState(() {});
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: onBackPressed,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Charade Parade Score'),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.clear),
              onPressed: () {
                if (gameModels.length > 0) {
                  showAlertDialog(context);
                }
              },
            ),
          ],
        ),
        body: Container(
          child: ListView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: gameModels.length,
              itemBuilder: (BuildContext context, int index) {
                print("Game -> " +
                    gameModels[index].user[0].playerGame.length.toString());
                return Card(
                  child: Container(
                    padding: EdgeInsets.all(10),
                    alignment: Alignment.center,
                    child: Column(
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(left: 5, right: 20),
                              child: Text(
                                (int.parse(gameModels[index].name) < 10)
                                    ? "0" +
                                        int.parse(gameModels[index].name)
                                            .toString()
                                    : int.parse(gameModels[index].name)
                                        .toString(),
                                style: TextStyle(color: Colors.white),
                              ),
                              padding: EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle, color: Colors.grey),
                            ),
                            /*Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text("Passed = " +
                                    gameModels[index]
                                        .user[0]
                                        .totalPassed
                                        .toString() +
                                    " Dare"),
                                Text("Completed = " +
                                    gameModels[index]
                                        .user[0]
                                        .totalSuccess
                                        .toString() +
                                    " Dare"),
                              ],
                            ),*/
                            Text(
                              gameModels[index]
                                      .user[0]
                                      .totalSuccess
                                      .toString() +
                                  "/" +
                                  gameModels[index]
                                      .user[0]
                                      .totalGame
                                      .toString() +
                                  " Completed",
                              style: TextStyle(
                                  fontSize: 17,
                                  color: gameModels[index].isWin
                                      ? Colors.green
                                      : Colors.red),
                            ),
                            Flexible(
                              child: Container(
                                color: Colors.transparent,
                              ),
                              flex: 1,
                            ),
                            Text(
                              (gameModels[index]
                                          .endDateTime
                                          .difference(
                                              gameModels[index].startDateTime)
                                          .inMilliseconds /
                                      1000)
                                  .toStringAsFixed(2),
                              style: TextStyle(
                                  fontSize: 17,
                                  color: gameModels[index].isWin
                                      ? Colors.green
                                      : Colors.red),
                            ),
                            GestureDetector(
                              child: Container(
                                padding: EdgeInsets.only(left: 10),
                                child: Icon(
                                  (gameModels[index].isVisible != null &&
                                          gameModels[index].isVisible)
                                      ? Icons.keyboard_arrow_up
                                      : Icons.keyboard_arrow_down,
                                  color:
                                      (gameModels[index].user[0].totalSuccess !=
                                                  null &&
                                              gameModels[index]
                                                      .user[0]
                                                      .totalSuccess >
                                                  0)
                                          ? Colors.grey
                                          : Colors.transparent,
                                ),
                              ),
                              onTap: () {
                                gameModels[index].isVisible =
                                    (gameModels[index].isVisible != null &&
                                            gameModels[index].isVisible)
                                        ? false
                                        : true;
                                setState(() {});
                              },
                            )
                          ],
                        ),
                        (gameModels[index].user[0].totalSuccess != null &&
                                gameModels[index].user[0].totalSuccess > 0)
                            ? Visibility(
                                visible: (gameModels[index].isVisible != null &&
                                    gameModels[index].isVisible),
                                child: Container(
                                  height: 100,
                                  margin: EdgeInsets.only(top: 10),
                                  child: ListView.builder(
                                      itemCount: gameModels[index]
                                          .user[0]
                                          .totalSuccess,
                                      scrollDirection: Axis.horizontal,
                                      itemBuilder:
                                          (BuildContext context, int index1) {
                                        return Container(
                                          margin: EdgeInsets.only(right: 10),
                                          child: Stack(
                                            children: <Widget>[
                                              Container(
                                                width: 100,
                                                height: 100,
                                                child: (gameModels[index]
                                                                .user[0]
                                                                .playerGame[
                                                                    index1]
                                                                .imagePath !=
                                                            null &&
                                                        gameModels[index]
                                                                .user[0]
                                                                .playerGame[
                                                                    index1]
                                                                .imagePath !=
                                                            "")
                                                    ? GestureDetector(
                                                        child: Image.file(
                                                          File(gameModels[index]
                                                              .user[0]
                                                              .playerGame[
                                                                  index1]
                                                              .imagePath),
                                                          fit: BoxFit.fill,
                                                        ),
                                                        onTap: () {
                                                          /*PhotoView(
                                                            imageProvider: FileImage(File(gameModels[index]
                                                                .user[0]
                                                                .playerGame[
                                                            index1]
                                                                .imagePath)),
                                                          );*/
                                                          showDiaImage(
                                                              context,
                                                              gameModels[index]
                                                                  .user[0]
                                                                  .playerGame[
                                                                      index1]
                                                                  .imagePath);
                                                        },
                                                      )
                                                    : Icon(
                                                        Icons.image,
                                                        size: 30,
                                                      ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.all(10),
                                                child: Text(
                                                  (index1 + 1).toString(),
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                                padding: EdgeInsets.all(5),
                                                decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: Colors.grey),
                                              ),
                                              Container(
                                                width: 100,
                                                child: Row(
                                                  children: <Widget>[
                                                    Flexible(
                                                      child: Container(
                                                        color:
                                                            Colors.transparent,
                                                      ),
                                                      flex: 1,
                                                    ),
                                                    GestureDetector(
                                                      child: Container(
                                                        padding:
                                                            EdgeInsets.all(5),
                                                        alignment: Alignment
                                                            .bottomCenter,
                                                        child: Container(
                                                          padding:
                                                              EdgeInsets.all(5),
                                                          decoration: BoxDecoration(
                                                              shape: BoxShape
                                                                  .circle,
                                                              color: Color(
                                                                  0x0033FFFFFF)),
                                                          child: Icon(
                                                            Icons.share,
                                                            color: Colors.white,
                                                          ),
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        shareImage(gameModels[
                                                                index]
                                                            .user[0]
                                                            .playerGame[index1]
                                                            .imagePath);
                                                      },
                                                    )
                                                  ],
                                                ),
                                              ),
                                              GestureDetector(
                                                child: Container(
                                                  padding: EdgeInsets.all(5),
                                                  alignment:
                                                      Alignment.bottomLeft,
                                                  child: Container(
                                                    padding: EdgeInsets.all(5),
                                                    decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: Color(
                                                            0x0033FFFFFF)),
                                                    child: Icon(
                                                      Icons.file_download,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ),
                                                onTap: () async {
                                                  // using your method of getting an image
                                                  final File image = await ImagePicker.pickImage(source: imageSource);
                                                  final String path = await getApplicationDocumentsDirectory().path;
                                                  final File newImage = await image.copy('$path/image1.png');
                                                },
                                              ),
                                            ],
                                          ),
                                        );
                                      }),
                                ),
                              )
                            : Container()
                      ],
                    ),
                  ),
                );
              }),
        ),
      ),
    );
  }

  // ignore: missing_return
  Future<bool> onBackPressed() {
    Navigator.of(context).pop();
  }

  showAlertDialog(BuildContext context) {
    // set up the buttons
    Widget cancelButton = FlatButton(
      child: Text("No"),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );
    Widget continueButton = FlatButton(
      child: Text("Yes"),
      onPressed: () {
        Shared_Preferences.prefSetInt(Shared_Preferences.keyGameCounter, 0)
            .then((onValue) {
          gameModels.clear();
          Navigator.of(context).pop();
          setState(() {});
        });
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Alert!"),
      content: Text("Are you sure want to clear all records?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
