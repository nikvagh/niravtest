package com.example.flutterapp

import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugins.GeneratedPluginRegistrant
import java.io.File


class MainActivity : FlutterActivity() {

    private val SHARE_CHANNEL = "channel:me.albie.share/share"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        GeneratedPluginRegistrant.registerWith(flutterEngine);
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SHARE_CHANNEL).setMethodCallHandler { methodCall, result ->
            if (methodCall.method == "shareFile") {
                shareFile((methodCall.arguments as String)!!)
            }
        }
    }

    private fun shareFile(path: String) {



        val shareIntent = Intent(Intent.ACTION_SEND)
        val phototUri = Uri.parse(path)

        val file = File(phototUri.path)


        if (file.exists()) {
            Toast.makeText(this.context, "$path yes", Toast.LENGTH_SHORT).show()
            // file create success
        } else {
            Toast.makeText(this.context, "$path no", Toast.LENGTH_SHORT).show()
            // file create fail
        }
        shareIntent.data = phototUri
        shareIntent.type = "image/*"
        shareIntent.putExtra(Intent.EXTRA_STREAM, phototUri)
        activity.startActivity(Intent.createChooser(shareIntent, "Share Via"))
        
        
//        val imageFile = File(this.applicationContext.cacheDir, path)
//        val contentUri: Uri = FileProvider.getUriForFile(this, "me.albie.share", imageFile)
//        val shareIntent = Intent(Intent.ACTION_SEND)
//        shareIntent.type = "image/jpg"
//        shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri)
//        this.startActivity(Intent.createChooser(shareIntent, "Share image using"))
    }
}
